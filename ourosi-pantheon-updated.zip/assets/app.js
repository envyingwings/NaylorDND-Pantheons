/* Shared utilities + landing page logic for The Ourosi Pantheon wiki. */

const DATA_URL = "data/deities.json?v=ea9e2a71";

/** Load the deity dataset once and cache it on window. */
async function loadDeities() {
  if (window.__deities) return window.__deities;
  const res = await fetch(DATA_URL);
  if (!res.ok) throw new Error("Failed to load deities.json: " + res.status);
  const data = await res.json();
  window.__deities = data;
  return data;
}

/** Very small markdown-lite: **bold** and _italic_ -> <strong>/<em>. Escapes HTML first. */
function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function renderInline(str) {
  if (!str) return "";
  let out = escapeHtml(str);
  out = out.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  out = out.replace(/(^|[^\w])_(.+?)_($|[^\w])/g, "$1<em>$2</em>$3");
  return out;
}

function iconPath(deity) {
  const ext = deity && deity.icon_ext ? deity.icon_ext : "svg";
  const slug = (deity && deity.icon_slug) || (deity && deity.slug);
  return `assets/icons/${slug}.${ext}`;
}

/** Classic D&D alignment ordering, good-to-evil then lawful-to-chaotic within each. */
const ALIGNMENT_ORDER = [
  "Lawful Good",
  "Neutral Good",
  "Chaotic Good",
  "Lawful Neutral",
  "True Neutral",
  "Chaotic Neutral",
  "Lawful Evil",
  "Neutral Evil",
  "Chaotic Evil",
];

function alignmentSortIndex(alignment) {
  const idx = ALIGNMENT_ORDER.indexOf(alignment);
  return idx === -1 ? ALIGNMENT_ORDER.length : idx;
}

/** Splits a "Name, Epithet" display name into its two parts. Falls back to
 * treating the whole string as the name if there's no comma. */
function splitNameEpithet(fullName) {
  const idx = fullName.indexOf(",");
  if (idx === -1) return { name: fullName.trim(), epithet: "" };
  return {
    name: fullName.slice(0, idx).trim(),
    epithet: fullName.slice(idx + 1).trim(),
  };
}

/** Renders a deity's name per the current landing-page display mode:
 * "name" -> just the name; "epithet" -> just the epithet (falls back to
 * name if there is none); "both" -> name and epithet stacked on separate
 * lines (no comma). */
function displayNameHtml(d, mode) {
  const { name, epithet } = splitNameEpithet(d.name);
  if (mode === "epithet") {
    return renderInline(epithet || name);
  }
  if (mode === "both") {
    if (!epithet) return renderInline(name);
    return `${renderInline(name)}<span class="epithet-line">${renderInline(epithet)}</span>`;
  }
  return renderInline(name);
}

/* ---------------- Landing page ---------------- */

function deityCardHtml(d, nameMode) {
  const href = d._cardHref || (d.multi_aspect
    ? `deity.html?d=${encodeURIComponent(d.slug)}&source=greater`
    : `deity.html?d=${encodeURIComponent(d.slug)}`);
  const iconSource = d._cardIcon || d;
  return `
    <a class="deity-card" href="${href}" data-slug="${d.slug}">
      <img class="symbol" src="${iconPath(iconSource)}" alt="${escapeHtml(d.name)} symbol" loading="lazy">
      <h2 class="card-name card-name--${nameMode}">${displayNameHtml(d, nameMode)}</h2>
      <p class="portfolio">${renderInline(d.portfolio || "")}</p>
      <span class="alignment-tag">${escapeHtml(d.alignment || "Unaligned")}</span>
    </a>
  `;
}

function initLandingPage() {
  const grid = document.getElementById("deity-grid");
  const searchInput = document.getElementById("search");
  const alignmentFilter = document.getElementById("alignment-filter");
  const nameModeSelect = document.getElementById("name-mode");
  const resultCount = document.getElementById("result-count");
  const tabButtons = Array.from(document.querySelectorAll(".pantheon-tab"));
  if (!grid) return;

  // Which tag identifies membership in each pantheon tab. A deity can carry
  // both tags (e.g. Moradin is Greater Pantheon and head of the Dwarven
  // Pantheon) and will appear on both tabs. An optional `exclude` tag lets a
  // tab omit deities that would otherwise match -- e.g. Eilistraee, Lolth,
  // and Vhaeraun all carry ElvenPantheon (their elven origin) as well as
  // DrowPantheon, but belong on a future Drow tab by default, not here.
  // `expandAspects: true` means a multi-aspect deity (e.g. Seha-Angharradh)
  // shows one card per aspect on this tab instead of a single merged card --
  // used on the Elven tab, where Aerdrie, Hanali, and Sehanine are each
  // full pantheon members in their own right. Tabs without this flag (the
  // Greater Pantheon) show the single merged card instead.
  const PANTHEON_TAGS = {
    greater: { include: "OurosiDeity" },
    dwarven: { include: "DwarfPantheon" },
    elven: { include: "ElvenPantheon", exclude: "DrowPantheon", expandAspects: true },
  };

  loadDeities().then((deities) => {
    // Placeholders (unwritten pantheon members) don't appear in the main
    // directory -- only real, fully-written deity pages do. Placeholders
    // are still reachable by following a link from a deity's Appendix.
    const real = deities.filter((d) => !d.is_placeholder);

    // Sort alphabetically by display name (ignoring leading articles/titles noise)
    const sorted = [...real].sort((a, b) => a.name.localeCompare(b.name));

    // Active pantheon tab persists across visits, same as name display mode.
    const TAB_STORAGE_KEY = "ourosi-pantheon-tab";
    let activeTab = "greater";
    try {
      const saved = localStorage.getItem(TAB_STORAGE_KEY);
      if (saved && PANTHEON_TAGS[saved]) activeTab = saved;
    } catch (e) { /* localStorage unavailable, fall back to default */ }

    // Turns one multi-aspect deity record (e.g. Seha-Angharradh) into
    // several card-view objects, one per aspect, each linking straight to
    // that aspect's tab on the shared page. All four share the merged
    // page's own symbol image (not each aspect's individual icon), and the
    // combined/default aspect displays under its pantheon-context name
    // ("Angharradh" here on the Elven tab) rather than the landing-page
    // name used elsewhere ("Seha-Angharradh").
    // Mirrors SOURCE_NAME_OVERRIDES in deity-page.js: on the Elven Pantheon
    // tab, the combined aspect displays as "Angharradh" rather than the
    // "Seha-Angharradh" name used for its card on the Greater Pantheon tab.
    const ELVEN_ASPECT_NAME_OVERRIDES = { angharradh: "Angharradh, the Moonweaver" };

    function expandToAspectCards(d) {
      return d.aspects.map((a) => ({
        slug: d.slug,
        name: ELVEN_ASPECT_NAME_OVERRIDES[a.aspect_slug] || a.name,
        portfolio: a.portfolio,
        alignment: a.alignment,
        domains: d.domains,
        _cardHref: `deity.html?d=${encodeURIComponent(d.slug)}&aspect=${encodeURIComponent(a.aspect_slug)}&source=elven`,
        // Only the combined/Angharradh aspect uses the merged page's own
        // symbol; Aerdrie, Hanali, and Sehanine each keep their own icon.
        _cardIcon: a.aspect_slug === d.default_aspect
          ? d
          : { slug: a.aspect_slug, icon_ext: a.icon_ext },
      }));
    }

    function deitiesForActiveTab() {
      const cfg = PANTHEON_TAGS[activeTab];
      const matched = sorted.filter((d) => {
        const tags = d.tags || [];
        if (!tags.includes(cfg.include)) return false;
        if (cfg.exclude && tags.includes(cfg.exclude)) return false;
        return true;
      });
      if (!cfg.expandAspects) return matched;
      const expanded = [];
      matched.forEach((d) => {
        if (d.multi_aspect && Array.isArray(d.aspects) && d.aspects.length > 0) {
          expanded.push(...expandToAspectCards(d));
        } else {
          expanded.push(d);
        }
      });
      // Expansion replaces one record (sorted by its own top-level name,
      // e.g. "Seha-Angharradh...") with several cards under their own
      // distinct display names (e.g. "Angharradh...", "Aerdrie Faenya...")
      // -- those need their own alphabetical position, so re-sort after
      // expanding rather than relying on the position the un-expanded
      // record held in `sorted`.
      expanded.sort((a, b) => a.name.localeCompare(b.name));
      return expanded;
    }

    // Rebuilds the alignment filter's options to match whichever alignments
    // are actually present among the active tab's deities, in classic D&D
    // order (good-to-evil, lawful-to-chaotic within each). Preserves the
    // current selection if it's still valid for the new tab, otherwise
    // resets to "All alignments".
    function rebuildAlignmentOptions() {
      const previousValue = alignmentFilter.value;
      const tabDeities = deitiesForActiveTab();
      const alignmentsPresent = new Set(tabDeities.map((d) => d.alignment).filter(Boolean));
      const alignments = ALIGNMENT_ORDER.filter((a) => alignmentsPresent.has(a));
      alignmentsPresent.forEach((a) => {
        if (!alignments.includes(a)) alignments.push(a);
      });

      alignmentFilter.innerHTML = "";
      const allOpt = document.createElement("option");
      allOpt.value = "";
      allOpt.textContent = "All alignments";
      alignmentFilter.appendChild(allOpt);
      alignments.forEach((a) => {
        const opt = document.createElement("option");
        opt.value = a;
        opt.textContent = a;
        alignmentFilter.appendChild(opt);
      });
      alignmentFilter.value = alignmentsPresent.has(previousValue) ? previousValue : "";
    }

    // Name display mode persists across visits (landing page only -- deity
    // pages always show the full "Name, Epithet" form regardless).
    const STORAGE_KEY = "ourosi-name-mode";
    let nameMode = "both";
    try {
      nameMode = localStorage.getItem(STORAGE_KEY) || "both";
    } catch (e) { /* localStorage unavailable, fall back to default */ }
    if (nameModeSelect) nameModeSelect.value = nameMode;

    function render() {
      const q = (searchInput.value || "").trim().toLowerCase();
      const alignFilter = alignmentFilter.value;
      const tabDeities = deitiesForActiveTab();
      const filtered = tabDeities.filter((d) => {
        if (alignFilter && d.alignment !== alignFilter) return false;
        if (!q) return true;
        const haystack = [
          d.name,
          d.portfolio,
          d.titles_line,
          ...(d.domains || []),
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        return haystack.includes(q);
      });

      resultCount.textContent = `${filtered.length} deit${filtered.length === 1 ? "y" : "ies"} shown`;

      if (filtered.length === 0) {
        grid.innerHTML = `<p class="no-results">No deities match your search.</p>`;
        return;
      }
      grid.innerHTML = filtered.map((d) => deityCardHtml(d, nameMode)).join("");
    }

    function setActiveTab(tab) {
      if (!PANTHEON_TAGS[tab]) return;
      activeTab = tab;
      try { localStorage.setItem(TAB_STORAGE_KEY, activeTab); } catch (e) { /* ignore */ }
      tabButtons.forEach((btn) => {
        btn.classList.toggle("active", btn.dataset.pantheon === activeTab);
      });
      rebuildAlignmentOptions();
      render();
    }

    tabButtons.forEach((btn) => {
      btn.addEventListener("click", () => setActiveTab(btn.dataset.pantheon));
    });

    searchInput.addEventListener("input", render);
    alignmentFilter.addEventListener("change", render);
    if (nameModeSelect) {
      nameModeSelect.addEventListener("change", () => {
        nameMode = nameModeSelect.value;
        try { localStorage.setItem(STORAGE_KEY, nameMode); } catch (e) { /* ignore */ }
        render();
      });
    }

    // Apply whichever tab was restored from storage (or the "greater"
    // default) before the first render, so the tab bar's active state and
    // the alignment options match what's actually displayed.
    setActiveTab(activeTab);
  }).catch((err) => {
    grid.innerHTML = `<p class="no-results">Could not load the pantheon data. (${escapeHtml(err.message)})</p>`;
    console.error(err);
  });
}

document.addEventListener("DOMContentLoaded", initLandingPage);
