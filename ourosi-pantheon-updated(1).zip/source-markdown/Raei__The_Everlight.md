---
base:
Divine Domains:
  - Beauty
  - Life
  - Light
  - Peace
Portfolio: Compassionate Goddess of Healing | Mercy, Redemption, Altruism, and Flame
Status:
  - Ourosi (Greater Deity)
Warlock Province:
  - Celestial
  - Genie (Fire)
  - Undying
Alignment: Neutral Good
tags:
  - OurosiDeity
  - CelestialPatron
  - GeniePatron
  - UndyingPatron
cover: "[[RaeiSymbol.webp]]"
---
```columns
id: -Raei-Page
===
**Sarenraei** (pronounced /ˈreɪ.i/ RAY-ee), the **Everlight**, embodies temperance and patience, teaching that even hardened hearts can be turned toward the light. She rules from the Island of Renewal within the Blessed Fields of Elysium, and believes wholly that the corrupt can be redeemed, a conviction that led to a betrayal by the Lord of the Hells, who decimated her followers during the Divergence. Only recently has her faith been rediscovered and her temples returned to prominence. Her followers are often rural healers and community philosophers, offering voices of reason and empathy in angry and cynical times.

- [[#Commandments of Raei|Commandments of Raei]]
===
### Sarenraei, the Everlight
[Miraheze](https://criticalrole.miraheze.org/wiki/Sarenrae) | [Pathfinder Wiki](https://pathfinderwiki.com/wiki/Sarenrae) | [PF2e (Archives of Nethys)](https://2e.aonprd.com/Deities.aspx?ID=16)
![[RaeiSymbol.webp]]
**Alignment.** Neutral Good
**Symbol.** A humanoid, feminine phoenix in flames.
**Portfolio.** Greater Goddess of Redemption, Altruism, Fire, and Healing.
**Divine Realm.** [[Blessed Fields of Elysium|Island of Renewal, Blessed Fields of Elysium]]
**Worshippers.** Healers, desert cultures, reformed criminals, the charitable
```
**Titles:** Sarenrae, Everlight, Phoenix Princess, Dawnflower, Healing Flame, Sister Cinder
**Domains:** Life, Light, Peace
### Commandments of Sarenraei
- Lead with mercy, patience, and compassion. Inspire others to unite in fellowship.
- Aid those who are without guide. Heal those who are without hope.
- Celebrate the beauty in all things. Let your heart be open to love and your hands be guided to create and nurture.
